# Career Trajectory Intelligence: Promotion Gap Risk Scoring and Retention Opportunity Identification

**Prepared by:** Shipra Sahani  
**Project type:** HR Analytics / Data Science  
**Tools:** Python, Pandas, NumPy, Scikit-learn, Plotly, Streamlit

## Abstract
This project explores employee career progression patterns using an HR analytics dataset. It engineers promotion-gap, role-stagnation, training-intensity, and manager-tenure proxy features; preprocesses numerical and categorical fields; and compares K-Means clustering with hierarchical clustering. It also defines transparent, rule-based promotion-gap categories and a career-development opportunity indicator. The dashboard is designed to support exploratory analysis and voluntary development conversations. Findings must be populated from the actual generated outputs, and the dataset source should be independently verified before attributing the records to a named organization.

## 1. Background and Context
Employee attrition can be associated with multiple workplace and career factors. Traditional attrition analysis may identify historical patterns associated with employees leaving, but it does not necessarily describe career progression patterns. This project focuses on exploratory career trajectory intelligence, including promotion gaps, role tenure, training participation, and time with the current manager.

## 2. Problem Statement
The project aims to develop a data-driven view of employee career patterns, identify possible promotion stagnation, and highlight potential career-development opportunities. The analysis is descriptive and exploratory; it does not prove that a career factor caused an employee to leave.

## 3. Objectives
1. Engineer interpretable career trajectory features.
2. Preprocess numerical and categorical HR data.
3. Group similar career profiles with K-Means.
4. Compare clusters with hierarchical clustering.
5. Create a transparent promotion-gap score.
6. Develop a dashboard for exploring patterns and potential development opportunities.

## 4. Dataset Description
Record the filename, number of rows, number of columns, source URL if verified, date accessed, and data-use permission. The supplied file has 1,470 rows and 31 original columns. Its schema resembles the commonly used IBM HR Analytics Employee Attrition & Performance dataset; do not attribute it to Palo Alto Networks without independent verification.

## 5. Methodology
### 5.1 Data quality checks
Report missing cells, duplicate rows, data types, and range checks using the generated analysis outputs.

### 5.2 Feature engineering
- Promotion Gap Ratio = YearsSinceLastPromotion / YearsAtCompany
- Role Stagnation Index = YearsInCurrentRole / YearsAtCompany
- Training Intensity Score = TrainingTimesLastYear / YearsAtCompany
- Manager Continuity Proxy = YearsWithCurrManager / YearsAtCompany

Ratios are undefined for zero company tenure. The manager measure is a proxy, not a count of manager changes.

### 5.3 Preprocessing
Numerical features are median-imputed and standardized. Department and job role are mode-imputed and one-hot encoded. Exact duplicate records are removed. Valid extreme values should be investigated, not automatically deleted.

### 5.4 Clustering
K-Means is the primary algorithm. Hierarchical clustering is used for comparison. Candidate K-Means cluster counts are compared with silhouette scores. The chosen cluster count and actual score must be copied from the generated outputs.

### 5.5 Promotion Gap Scoring
Document the thresholds used in `analysis.py`. They are illustrative and require domain validation.

### 5.6 Retention Opportunity Indicator
Describe the transparent indicator and clarify that it is not a calibrated attrition probability or an employment decision rule.

## 6. Results
**Complete this section only after running `python analysis.py`.**

- Dataset quality: [insert values from `outputs/analysis_summary.json`]
- Silhouette scores: [insert values from `outputs/silhouette_scores.csv`]
- Cluster profiles: [summarize `outputs/cluster_profiles.csv`]
- Promotion gap categories: [calculate from `outputs/employee_career_analysis.csv`]
- Retention opportunity patterns: [calculate from actual output]
- Add the generated figures: `cluster_distribution.png` and `promotion_gap_distribution.png`.

Do not assign business names to cluster IDs without reviewing their actual profiles.

## 7. Streamlit Dashboard
Describe the four modules: Career Path Clustering, Promotion Gap Monitor, Retention Opportunity, and Managerial Insights. Include screenshots captured from the running application.

## 8. Recommendations
Potential actions for HR teams to consider include career conversations, mentoring, training plans, internal mobility, transparent promotion criteria, and manager support. Recommendations should be based on observed aggregate patterns and reviewed with relevant stakeholders.

## 9. Limitations and Ethical Considerations
The dataset source is not verified by the filename alone. The data are a snapshot and do not record full promotion histories or manager changes. Clusters do not prove causality. Thresholds are illustrative. Historical attrition is not a future prediction. Protect employee privacy, limit access to row-level information, and do not use these exploratory scores to make automated hiring, promotion, or termination decisions.

## 10. Conclusion
The project provides a framework for exploring career trajectory patterns and potential development needs. Its value depends on careful validation, transparent thresholds, accurate data provenance, and responsible interpretation.

## References
1. Scikit-learn documentation: https://scikit-learn.org/stable/
2. Streamlit documentation: https://docs.streamlit.io/
3. Pandas documentation: https://pandas.pydata.org/docs/
4. Dataset source and license: [insert verified original source and license before submission]
